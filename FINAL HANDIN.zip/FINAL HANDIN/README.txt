All of our data processing code in the dataset should be run from the directory that it is located in.

The Machine Learning Code in classifiers.py should be run with the flags -classifier dt/rf/svm. The regression code in regression.py should be run with appropriate flags (training and classifier).

Our visualizations must be loaded through a SimpleHTTPServer (or equivalent).