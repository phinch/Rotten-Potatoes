# Rotten-Potatoes

Final project for CS1951a: Data Science

Premise: Rotten Tomatoes for restaurants
